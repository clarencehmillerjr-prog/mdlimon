import React, { useState, useEffect } from 'react';
import Button from './Button';
import { User, Mail, Link as LinkIcon, Send, Phone, CheckCircle, Loader2 } from 'lucide-react';

// Custom hook for the typewriter effect
const useTypewriter = (phrases: string[], delay: number = 2000) => {
  const [text, setText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [loopNum, setLoopNum] = useState(0);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;

    const i = loopNum % phrases.length;
    const fullText = phrases[i];

    if (!isDeleting && text === fullText) {
      // Finished typing phrase, pause before deleting
      timer = setTimeout(() => setIsDeleting(true), delay);
    } else if (isDeleting && text === '') {
      // Finished deleting, move to next phrase
      setIsDeleting(false);
      setLoopNum((prev) => prev + 1);
    } else {
      // Typing or deleting characters
      timer = setTimeout(() => {
        setText(
          isDeleting
            ? fullText.substring(0, text.length - 1)
            : fullText.substring(0, text.length + 1)
        );
      }, isDeleting ? 50 : 100);
    }

    return () => clearTimeout(timer);
  }, [text, isDeleting, loopNum, phrases, delay]);

  return text;
};

const CTA: React.FC = () => {
  // Animated placeholders state
  const namePlaceholder = useTypewriter([
    "What is your name?",
    "e.g. John Doe",
    "e.g. Sarah Connor"
  ]);

  const emailPlaceholder = useTypewriter([
    "What is your email?",
    "e.g. john@example.com",
    "e.g. contact@business.com"
  ]);

  const socialPlaceholder = useTypewriter([
    "WhatsApp, Skype, or Telegram ID",
    "e.g. +1 234 567 8900",
    "e.g. @telegram_handle"
  ]);

  const messagePlaceholder = useTypewriter([
    "Tell me, How can I help you?",
    "I need a high-converting website...",
    "I want to improve my SEO ranking..."
  ]);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    social: '',
    message: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const { name, email, social, message } = formData;
    const subject = `New Quote Request from ${name}`;
    const fullMessage = `Name: ${name}\nEmail: ${email}\nSocial Link: ${social}\n\nMessage:\n${message}`;

    try {
      // Attempt 1: Automatic AJAX Submission to FormSubmit.co
      const response = await fetch("https://formsubmit.co/ajax/nilahamed9@gmail.com", {
        method: "POST",
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          name,
          email,
          social,
          message,
          _subject: subject,
          _captcha: "false" // Disable captcha for smoother experience
        })
      });

      if (response.ok) {
        setIsSubmitted(true);
        setFormData({ name: '', email: '', social: '', message: '' });
      } else {
        throw new Error("Form submission failed");
      }
    } catch (error) {
      console.error("Auto-send failed, falling back to mailto", error);
      
      // Attempt 2: Fallback to Mailto (Client-side)
      // Properly encode components to ensure the mail client opens correctly
      const mailtoLink = `mailto:nilahamed9@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(fullMessage)}`;
      window.location.href = mailtoLink;
      
      // Still show submitted state so user knows action was taken
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-24 relative" id="contact">
      <div className="absolute inset-0 bg-slate-950"></div>
      {/* Glow effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-4xl max-h-[600px] bg-primary/10 blur-[100px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="flex flex-col lg:flex-row items-start gap-16">
          
          {/* Text Content */}
          <div className="flex-1 lg:sticky lg:top-24 text-center lg:text-left">
            <h2 className="text-4xl md:text-6xl font-display font-bold text-white mb-6 tracking-tight">
              Ready to <span className="text-primary">scale</span> your business?
            </h2>
            <p className="text-slate-400 text-xl mb-8 leading-relaxed">
              In 2025, speed and precision matter. Let's discuss how we can transform your digital presence into a 24/7 sales engine.
            </p>
            
            <div className="hidden lg:block space-y-6">
                <a href="mailto:mdlimonkazi09@gmail.com" className="flex items-center gap-4 text-slate-300 hover:text-white transition-colors group">
                    <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-primary group-hover:border-primary/50 transition-colors">
                        <Mail size={20} />
                    </div>
                    <div>
                        <p className="text-sm text-slate-500">Email Me</p>
                        <p className="font-medium">mdlimonkazi09@gmail.com</p>
                    </div>
                </a>
                 <a href="https://wa.me/8801761604425" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 text-slate-300 hover:text-white transition-colors group">
                    <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-accent group-hover:border-accent/50 transition-colors">
                        <Phone size={20} />
                    </div>
                    <div>
                        <p className="text-sm text-slate-500">WhatsApp Me</p>
                        <p className="font-medium">+8801761-604425</p>
                    </div>
                </a>
            </div>
          </div>

          {/* Form Content */}
          <div className="flex-1 w-full">
            <div className="bg-slate-900/50 backdrop-blur-md border border-slate-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden group min-h-[500px] flex items-center">
               {/* Decorative border gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-50 pointer-events-none"></div>

              {isSubmitted ? (
                <div className="w-full text-center space-y-6 py-12 animate-fade-in">
                  <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto text-green-500">
                    <CheckCircle size={40} />
                  </div>
                  <h3 className="text-2xl font-bold text-white">Message Sent!</h3>
                  <p className="text-slate-400">
                    Thank you for reaching out. I will get back to you at <strong>{formData.email || 'your email'}</strong> within 2 hours.
                  </p>
                  <Button onClick={() => setIsSubmitted(false)} variant="outline">
                    Send Another Message
                  </Button>
                </div>
              ) : (
                <form className="relative z-10 space-y-6 w-full" onSubmit={handleSubmit}>
                  
                  {/* Name Input */}
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-slate-300 ml-1">Full Name</label>
                    <div className="relative">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">
                        <User size={18} />
                      </div>
                      <input 
                        type="text" 
                        id="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-slate-950/50 border border-slate-700 text-white rounded-xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all duration-300 outline-none placeholder:text-slate-600"
                        placeholder={namePlaceholder}
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>

                  {/* Email Input */}
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-slate-300 ml-1">Email Address</label>
                    <div className="relative">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">
                        <Mail size={18} />
                      </div>
                      <input 
                        type="email" 
                        id="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-slate-950/50 border border-slate-700 text-white rounded-xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all duration-300 outline-none placeholder:text-slate-600"
                        placeholder={emailPlaceholder}
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>

                  {/* Social Links Input */}
                  <div className="space-y-2">
                    <label htmlFor="social" className="text-sm font-medium text-slate-300 ml-1">Social Link (WhatsApp / Telegram / Skype)</label>
                    <div className="relative">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">
                        <LinkIcon size={18} />
                      </div>
                      <input 
                        type="text" 
                        id="social"
                        value={formData.social}
                        onChange={handleInputChange}
                        className="w-full bg-slate-950/50 border border-slate-700 text-white rounded-xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all duration-300 outline-none placeholder:text-slate-600"
                        placeholder={socialPlaceholder}
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>

                  {/* Message Input */}
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium text-slate-300 ml-1">How can I help you?</label>
                    <div className="relative">
                      <textarea 
                        id="message"
                        rows={4}
                        value={formData.message}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-slate-950/50 border border-slate-700 text-white rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all duration-300 outline-none placeholder:text-slate-600 resize-none"
                        placeholder={messagePlaceholder}
                        disabled={isSubmitting}
                      ></textarea>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    variant="primary" 
                    className="w-full h-14 text-lg mt-4 group disabled:opacity-70 disabled:cursor-not-allowed"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center">
                        <Loader2 size={20} className="animate-spin mr-2" />
                        Sending...
                      </span>
                    ) : (
                      <>
                        <span className="mr-2">Get My Free Quote</span>
                        <Send size={18} className="group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </Button>

                  <p className="text-center text-slate-500 text-xs mt-4">
                    I usually respond within 2 hours. Your details are 100% secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;