import React from 'react';
import { Search, Share2, TrendingUp, Zap } from 'lucide-react';

const ValueProposition: React.FC = () => {
  return (
    <section className="py-24 bg-slate-950 relative overflow-hidden" id="about">
        {/* Grid Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-6">
            Dominating the <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Digital Space</span> in 2025.
          </h2>
          <p className="text-slate-400 text-lg">
            The digital market is more crowded than ever. Strategic SEO and Social Media Marketing (SMM) are no longer optional—they are the oxygen of your business.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Card 1: SEO */}
          <div className="group relative p-8 rounded-3xl bg-slate-900/50 border border-slate-800 hover:border-primary/50 transition-all duration-300 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10 flex flex-col items-start">
              <div className="w-14 h-14 bg-slate-800 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Search className="w-7 h-7 text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Data-Driven SEO</h3>
              <p className="text-slate-400 mb-6 leading-relaxed">
                I don't just guess; I analyze. Using advanced 2025 analytics, I structure your site to speak the language of search engines, ensuring your products don't just exist, but thrive and sell.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center text-slate-300 text-sm">
                    <TrendingUp className="w-4 h-4 text-accent mr-3" />
                    Keyword Domination
                </li>
                <li className="flex items-center text-slate-300 text-sm">
                    <Zap className="w-4 h-4 text-accent mr-3" />
                    Core Web Vitals Optimization
                </li>
              </ul>
            </div>
          </div>

          {/* Card 2: SMM */}
          <div className="group relative p-8 rounded-3xl bg-slate-900/50 border border-slate-800 hover:border-accent/50 transition-all duration-300 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10 flex flex-col items-start">
              <div className="w-14 h-14 bg-slate-800 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Share2 className="w-7 h-7 text-accent" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Social Media Marketing</h3>
              <p className="text-slate-400 mb-6 leading-relaxed">
                Connecting with your audience requires empathy and strategy. I craft social campaigns that resonate, building a community of loyal advocates around your brand.
              </p>
               <ul className="space-y-3">
                <li className="flex items-center text-slate-300 text-sm">
                    <TrendingUp className="w-4 h-4 text-primary mr-3" />
                    Viral Content Strategy
                </li>
                <li className="flex items-center text-slate-300 text-sm">
                    <Zap className="w-4 h-4 text-primary mr-3" />
                    High-Conversion Ad Campaigns
                </li>
              </ul>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default ValueProposition;