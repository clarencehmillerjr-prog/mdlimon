import React from 'react';
import { ArrowUpRight, MessageSquare } from 'lucide-react';
import Button from './Button';

const services = [
  {
    title: "Web Design & Development",
    description: "Custom, high-performance websites built with modern technologies (React, Tailwind) that look great on all devices and convert visitors into customers.",
    image: "https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&q=80&w=800", // Web Design placeholder
  },
  {
    title: "SEO Optimization",
    description: "Data-driven SEO strategies to boost your ranking on Google. I optimize for speed, keywords, and user experience to drive organic traffic.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800", // Analytics/SEO placeholder
  },
  {
    title: "Social Media Marketing",
    description: "Strategic social media campaigns that engage your audience and build brand loyalty. From content creation to ad management.",
    image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800", // Social Media placeholder
  },
];

const Services: React.FC = () => {
  return (
    <section className="py-24 bg-slate-950 relative" id="services">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-primary/5 blur-[100px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-accent/5 blur-[100px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-6">
            My <span className="text-primary">Services</span>
          </h2>
          <div className="w-24 h-1 bg-accent mx-auto rounded-full mb-6"></div>
          <p className="text-slate-300 text-lg leading-relaxed italic">
            "I believe in client satisfaction. Because when my clients are satisfied, it helps me excel in my work."
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="group bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-primary/50 transition-all duration-300 flex flex-col"
            >
              {/* Image Area */}
              <div className="h-48 overflow-hidden relative">
                <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-transparent transition-colors duration-300 z-10"></div>
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              {/* Content Area */}
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-primary transition-colors">
                  {service.title}
                </h3>
                <p className="text-slate-400 text-sm mb-6 flex-1 leading-relaxed">
                  {service.description}
                </p>

                {/* Buttons */}
                <div className="flex flex-col gap-3 mt-auto">
                  <Button 
                    variant="outline" 
                    href="#fiverr" 
                    className="w-full justify-center text-xs py-2 h-10 border-slate-700 hover:border-accent hover:text-slate-950"
                  >
                    <span className="mr-2">Hire on Fiverr</span>
                    <ArrowUpRight size={14} />
                  </Button>
                  <Button 
                    variant="primary" 
                    href="#contact" 
                    className="w-full justify-center text-xs py-2 h-10 shadow-none hover:shadow-md"
                  >
                    <span className="mr-2">Get My Free Quote</span>
                    <MessageSquare size={14} />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default Services;