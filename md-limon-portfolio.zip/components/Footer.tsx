import React from 'react';
import { Github, Linkedin, Twitter, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          
          <div className="mb-6 md:mb-0 text-center md:text-left">
            <a href="#" className="font-display font-bold text-2xl text-white tracking-tighter inline-block group">
              MD <span className="text-primary">Limon</span>
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-accent ml-1 mb-0.5 group-hover:animate-pulse"></span>
            </a>
            <p className="text-slate-500 mt-2 text-sm">
              © 2025 MD Limon. All rights reserved.
            </p>
          </div>

          <div className="flex space-x-6">
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              <Linkedin size={20} />
            </a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              <Twitter size={20} />
            </a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              <Github size={20} />
            </a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              <Mail size={20} />
            </a>
          </div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;